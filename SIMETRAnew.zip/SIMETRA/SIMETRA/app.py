from flask import Flask,render_template,request,redirect
from flask_sqlalchemy import SQLAlchemy

app=Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI']='sqlite://meubanco.db'
db=SQLAlchemy(app)
@app.route('/')
def home():
    return

class Usuario(db.model):
    cpf=db.Column(db.String(14), nullable=False)
    usernome=db.Column(db.String(80), nullable=False)    
    cep=db.Column(db.String(9), nullable=False)
    email=db.Column(db.String(80), nullable=False)

class Cursos(db.model):
    cursonome=db.Column(db.String(80),nullable=False)
    descricao=db.Column(db.string(200), nullable=True)
    #empresa chave estrangeira
    id=db.Column(db.Integer)

class Empresas(db.model):
    empresanome=db.Column(db.String(80), nullable=False)
    empresaid=db.Column(db.Integer,nullable=False)
    empresadescricao=db.Colum(db.String(200), nullable=False)
if __name__=='__main__':
    app.run(debug=True)